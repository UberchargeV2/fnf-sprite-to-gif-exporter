Hello,

First of all, thank you for downloading this tool!
It's really cool to see people enjoying my work.

Now let's get to the point:

HOW TO USE:
Go and find the XML, JSON, and PNG files for your GIF inside your Friday Night Funkin' folder.
They are usually located in:
- "game/mods/images/characters" for the PNG and XML files
- "game/mods/characters" for the JSON file

(These paths may vary from mod to mod, so be aware!)

Now, copy all those files and place them in the "input" folder inside the tool.

If you'd like, you can edit the "SCRIPT_CONFIG.txt" file to change preferences.

After that, simply double-click and run the "make_gif_run.bat" file.
You’ll see a command prompt appear where you can monitor what the tool is doing.

Once it finishes, open the "output_gifs" folder and collect your freshly baked GIFs!

Made with love by Übercharge / @uberchargev2
