import xml.etree.ElementTree as ET
from PIL import Image
import json
import os
from pathlib import Path

# === CONFIG FILE ===
CONFIG_PATH = "SCRIPT_CONFIG.txt"
DEFAULT_CONFIG = {
    "folder_based": True,
    "input_folder": "input",
    "output_folder": "output_gifs",
    "use_frame_scaling_parameters": True,
    "use_auto_center_offsetting": True,
    "game_engine": "psych"
}

def load_config():
    config = DEFAULT_CONFIG.copy()
    if not os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            f.write("// === SCRIPT_CONFIG ===\n")
            f.write("folder_based = 1\n")
            f.write("// Enables the script to work with input folders. If there are multiple XML, PNG, and JSON files, it will look for the ones with the same names and use them.\n")
            f.write("// You can also disable this, but you will need to place the images in the same folder as the script and manually edit the input parameters.\n")
            f.write("use_frame_scaling_parameters = 0\n")
            f.write("// Uses the frameWidth=\"x\" and frameHeight=\"x\" attributes to determine the resolution of the output GIF instead of the width=\"x\" and height=\"x\".\n")
            f.write("use_auto_center_offsetting = 1\n")
            f.write("// If enabled, it ignores the offsetting data from the files and centers the image in the middle.\n")
            f.write("// If disabled, it uses the centering data from the files themselves, behaving like the game does.\n")
            f.write("game_engine = psych\n")
            f.write("// This is important — it determines how the code handles your files! Make sure this is set correctly or you will get broken GIFs or errors!\n")
            f.write("\n")
            f.write("// 1 = enabled\n")
            f.write("// 0 = disabled\n")
            f.write("// psych = Psych Engine\n")
            f.write("// kade = Kade Engine\n")
            f.write("// fpsplus = FPS Plus Engine\n")
            f.write("\n")
            f.write("// Made with love by Übercharge/uberchargev2\n")
        print("⚠️ No config found. Created default SCRIPT_CONFIG.txt. Edit and rerun if needed.")
        return config

    with open(CONFIG_PATH, "r") as f:
        for line in f:
            line = line.strip()
            if line.startswith("//") or "=" not in line:
                continue
            key, value = map(str.strip, line.split("=", 1))
            if key == "folder_based":
                config["folder_based"] = value == "1"
            elif key == "input_folder":
                config["input_folder"] = value.strip('"')
            elif key == "output_folder":
                config["output_folder"] = value.strip('"')
            elif key == "use_frame_scaling_parameters":
                config["use_frame_scaling_parameters"] = value == "1"
            elif key == "use_auto_center_offsetting":
                config["use_auto_center_offsetting"] = value == "1"
            elif key == "game_engine":
                config["game_engine"] = value.lower()
    return config


def load_sprite_sheet(xml_path, png_path, use_frame_scaling, auto_center, engine):
    sprite_sheet = Image.open(png_path).convert("RGBA")
    tree = ET.parse(xml_path)
    root = tree.getroot()

    frames = []
    for subtexture in root.findall("SubTexture"):
        name = subtexture.attrib["name"].split(".")[0]
        x = int(subtexture.attrib["x"])
        y = int(subtexture.attrib["y"])
        w = int(subtexture.attrib["width"])
        h = int(subtexture.attrib["height"])
        frameX = int(subtexture.attrib.get("frameX", 0))
        frameY = int(subtexture.attrib.get("frameY", 0))
        frameW = int(subtexture.attrib.get("frameWidth", w))
        frameH = int(subtexture.attrib.get("frameHeight", h))

        cropped = sprite_sheet.crop((x, y, x + w, y + h))

        if use_frame_scaling:
            full_img = Image.new("RGBA", (frameW, frameH), (0, 0, 0, 0))

            if engine in ["fpsplus"]:
                # FPS Plus Engine assumes top-left alignment (no offset)
                paste_x, paste_y = 0, 0
            elif auto_center:
                paste_x = (frameW - w) // 2
                paste_y = (frameH - h) // 2
            else:
                paste_x = abs(frameX) if frameX < 0 else frameX
                paste_y = abs(frameY) if frameY < 0 else frameY

            full_img.paste(cropped, (paste_x, paste_y))
            frames.append((name, full_img))
        else:
            frames.append((name, cropped))
    return frames

def save_gif(animation_name, frames, framerate, output_dir, auto_center):
    if auto_center:
        max_w = max(f.width for f in frames)
        max_h = max(f.height for f in frames)
        padded = []
        for img in frames:
            canvas = Image.new("RGBA", (max_w, max_h), (0, 0, 0, 0))
            px = (max_w - img.width) // 2
            py = (max_h - img.height) // 2
            canvas.paste(img, (px, py))
            padded.append(canvas)
    else:
        padded = frames

    output_path = os.path.join(output_dir, f"{animation_name}.gif")
    padded[0].save(
        output_path,
        save_all=True,
        append_images=padded[1:],
        duration=int(1000 / framerate),
        loop=0,
        disposal=2,
        transparency=0
    )
    print(f"✔️ Saved: {output_path}")

def process_animation_set(xml_file, png_file, json_file, output_dir, use_frame_scaling, auto_center):
    frame_list = load_sprite_sheet(xml_file, png_file, use_frame_scaling, auto_center, config["game_engine"])

    with open(json_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    for anim in data.get("animations", []):
        anim_name = anim.get("anim", "unnamed")
        prefix = anim.get("name", anim_name)
        indices = anim.get("indices", [])
        framerate = anim.get("fps", 24)

        if indices:
            try:
                selected = [frame_list[i][1] for i in indices]
            except IndexError:
                print(f"❌ Skipping '{anim_name}' — index out of range.")
                continue
        else:
            selected = [img for fname, img in frame_list if fname.startswith(prefix)]

        if not selected:
            print(f"⚠️ Skipping '{anim_name}' — no matching frames for prefix '{prefix}'")
            continue

        save_gif(anim_name, selected, framerate, output_dir, auto_center)

# === MAIN EXECUTION ===
config = load_config()

if config["folder_based"]:
    input_path = Path(config["input_folder"])
    output_path = Path(config["output_folder"])
    os.makedirs(input_path, exist_ok=True)
    os.makedirs(output_path, exist_ok=True)

    triplet_groups = {}
    for file in input_path.glob("*"):
        stem = file.stem
        triplet_groups.setdefault(stem, []).append(file)

    processed = set()
    for stem, files in triplet_groups.items():
        xml_file = next((f for f in files if f.suffix.lower() == ".xml"), None)
        png_file = next((f for f in files if f.suffix.lower() == ".png"), None)
        json_file = next((f for f in files if f.suffix.lower() == ".json"), None)

        if all([xml_file, png_file, json_file]):
            processed.update([xml_file, png_file, json_file])
            print(f"\n🔍 Processing set: {stem}")
            process_animation_set(xml_file, png_file, json_file, str(output_path), config["use_frame_scaling_parameters"], config["use_auto_center_offsetting"])

    # Fallback for unmatched files
    remaining_files = list(input_path.glob("*"))
    xml_file = next((f for f in remaining_files if f.suffix.lower() == ".xml" and f not in processed), None)
    png_file = next((f for f in remaining_files if f.suffix.lower() == ".png" and f not in processed), None)
    json_file = next((f for f in remaining_files if f.suffix.lower() == ".json" and f not in processed), None)

    if all([xml_file, png_file, json_file]):
        print("\n⚠️ No exact name match, but found valid XML/PNG/JSON files. Proceeding anyway.")
        process_animation_set(xml_file, png_file, json_file, str(output_path), config["use_frame_scaling_parameters"], config["use_auto_center_offsetting"])
else:
    # === MANUAL MODE ===
    XML_FILE = "your.xml"
    PNG_FILE = "your.png"
    JSON_FILE = "your.json"
    OUTPUT_DIR = "output_gifs/manual"

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print(f"\n🔧 Manual Mode: Processing {XML_FILE}, {PNG_FILE}, {JSON_FILE}")
    process_animation_set(XML_FILE, PNG_FILE, JSON_FILE, OUTPUT_DIR, config["use_frame_scaling_parameters"], config["use_auto_center_offsetting"])
